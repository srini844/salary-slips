package learningFn_Interface;

import java.util.Comparator;

public class Laptop {

	String model;
	int price;
	int Ram;
	boolean touch;
	
	public Laptop(String model, int price, int Ram, boolean touch) {
		this.model=model;
		this.price=price;
		this.Ram=Ram;
		this.touch=touch;
	}

public String toString() {
	return this.model.toString();
}

}

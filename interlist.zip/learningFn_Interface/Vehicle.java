package learningFn_Interface;

import com.google.common.base.Predicate;

public class Vehicle {

	public static void main(String[] args) {
		Predicate<String> p = (value) -> value.equalsIgnoreCase("TwoWheeler");
		p.test("FourWheeler");

		System.out.println(p.test("FourWheeler"));
		System.out.println(p.test("TwoWheeler"));
	}

	/*
	 * Predicate<String> p = (String value)-> { if
	 * (value.equalsIgnoreCase("TwoWheeler")) { return true; } return false; };
	 */

}

package learningFn_Interface;

import java.util.ArrayList;
import java.util.Collections;

public class CollectionsDemo {

	public static void main(String[] args) {
		
		
		Laptop l1 = new Laptop("Hp",45000,4,true);
		Laptop l2 = new Laptop("Dell",95000,16,true);
		Laptop l3 = new Laptop("Apple",55000,8,true);
		
		
		ArrayList al = new ArrayList();
		al.add(l1);
		al.add(l2);
		al.add(l3);
		
		ComparatorDemo cd = new ComparatorDemo();
		
		Collections.sort(al, cd);
			System.out.println("After Sort: "+al);
			Collections.reverse(al);
			System.out.println("After Reverse: "+al);
	}

}

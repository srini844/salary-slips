package learningFn_Interface;


@FunctionalInterface
public interface Bike {

	public void fourWheeler();

	public default void twhWheeler(String value) {
		System.out.println("Called" +  value);
	}
	


	

}

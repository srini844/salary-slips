package learningFn_Interface;

import java.util.Comparator;

public class ComparatorDemo implements Comparator {

	

	
	@Override
	public int compare(Object o1, Object o2) {
		Laptop l1 = (Laptop) o1;
		Laptop l2 = (Laptop) o2;

		int comparedVal = l1.model.compareTo(l2.model);
		if (comparedVal > 0)
			return 1;
		else if (comparedVal < 0)
			return -1;

		return 0;
	}

}

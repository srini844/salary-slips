package lLinkedList;

public class Demo {
	public static void main(String[] args) {
		
		
		LinkedList list = new LinkedList();
		list.insertAtBeginning(9);
		list.insertAtBeginning(5);
		list.insertAtPosition(5, 10);
		list.display();
		
	}


}

package interview;

import java.nio.file.spi.FileSystemProvider;

public class SamplePgm {
	
	

public static void main(String[] args) {
	
	String strInput="Opeenntexxt";
		

	String temp=null;
	char[] charArray = strInput.toCharArray();
	
	for(int i=0;i<charArray.length-1;i++) {
		if(charArray[i]!=charArray[i++]) {
			
			System.out.println(temp+= charArray[i]);
		}
		
		else if(charArray[i]==charArray[i+1]){	
			System.out.println(temp+= charArray[i+1]);
			
			i=i+1;
	
		}
		
		
		
	}
	
	
}

}

package myProgram;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public class CookiesPgm {

	boolean flag = false;

	@Test()
	public void test() throws FileNotFoundException, InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		ChromeDriver driver = new ChromeDriver();

		if (flag) {
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.navigate().to("https://accs-gemini-ui-release.app.singdev1.paas.fedex.com/");
			Thread.sleep(8000);
			driver.findElement(By.xpath("//input[@autocomplete='username']")).sendKeys("4515335");
			driver.findElement(By.xpath("//input[@autocomplete='current-password']")).sendKeys("thith@2024");
			driver.findElement(By.xpath("//input[@value='Sign in']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//input[@value='Send push']")).click();
			Thread.sleep(5000);
			Set<Cookie> cookies = driver.manage().getCookies();
			try (FileWriter writer = new FileWriter("./Cookies/cookies.json")) {
				writer.write(new Gson().toJson(cookies));
			} catch (IOException e) {
				e.printStackTrace();
			}
			Thread.sleep(5000);
			driver.close();
		} else {
			driver.navigate().to("https://accs-gemini-ui-release.app.singdev1.paas.fedex.com/");
			driver.manage().deleteAllCookies();
			try (FileReader reader = new FileReader("./Cookies/cookies.json")) {
				Type cookieType = new TypeToken<Set<Cookie>>() {
				}.getType();
				Set<Cookie> loadedCookies = new Gson().fromJson(reader, cookieType);

				// Add loaded cookies back to the session
				for (Cookie cookie : loadedCookies) {
					driver.manage().addCookie(cookie);
				}
				driver.navigate().to("https://accs-gemini-ui-release.app.singdev1.paas.fedex.com/");
//				driver.navigate().refresh();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		

	}

}







//			Gson gson = new Gson();
//			Reader reader = new FileReader("./Cookies/cookies.json");
//			
//				Cookie[] cookies = gson.fromJson(reader, Cookie[].class);				
//				Arrays.stream(cookies).forEach(driver.manage()::addCookie);
//				driver.navigate().to("https://accs-gemini-ui-release.app.singdev1.paas.fedex.com/");

package myProgram;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SampleProgram {

	
	@Test
	public void testApplication() {

		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Ragunath");
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Muthusamy");
		driver.findElement(By.xpath("(//input[@name='sex'])[1]")).click();
		driver.findElement(By.xpath("(//input[@name='exp'])[7]")).click();
		driver.close();
		

	}

}

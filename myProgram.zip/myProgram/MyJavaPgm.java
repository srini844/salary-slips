package myProgram;

import org.testng.annotations.Test;

public class MyJavaPgm {
	
	@Test()
	public void pgm1() {

		int nums[] = { 2, 7, 11, 15 };

		//System.out.println("Length of an array : " + nums.length);
		int i = 0;

		while ((nums.length)-1 != 0) {
			if (nums[i] + nums[i + 1] == 9) {
				System.out.println("Program 1 -> Output is :" + i + "," + (i + 1));
				break;
			} else {
				i += 1;
			}

		}

	}
	
	
	@Test()
	public void pgm2() {

		int nums[] = { 3, 2, 4 };

		//System.out.println("Length of an array : " + nums.length);
		int i = 0;

		while ((nums.length)-1 != 0) {
			if (nums[i] + nums[i + 1] == 6) {
				System.out.println("Program 2 -> Output is :" + i + "," + (i + 1));
				break;
			} else {
				i += 1;
			}

		}

	}
	
	
	
	@Test()
	public void pgm3() {

		int nums[] = { 3, 3 };

		System.out.println("Length of an array : " + nums.length);
		int i = 0;

		while ((nums.length-1) != 0) {
			if (nums[i] + nums[i + 1] == 6) {
				System.out.println("Program 3 -> Output is :" + i + "," + (i + 1));
				break;
			} else {
				i += 1;
			}

		}

	}
	
	
	

}

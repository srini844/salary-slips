package test;

import java.util.ArrayList;
import java.util.Random;

public class RandomStringGeneration {
	public static void main(String[] args) {
		Random rnd = new Random();
		String expString="";
		String str = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890";

		//Method 1	
		if (expString.length()<= 0) {
			while (expString.length() != 10) {
				char strFormation = str.charAt(rnd.nextInt(str.length()-1));

				expString+=strFormation;
			}
			System.out.println(expString);
		}

		//Method 2
		StringBuilder strBuilder = new StringBuilder();
		if(strBuilder.length()<=0) {
			while(strBuilder.length()!=5) {
				strBuilder.append(str.charAt(rnd.nextInt(str.length())));			
			}
			System.out.println(strBuilder);				

		}
	}


}

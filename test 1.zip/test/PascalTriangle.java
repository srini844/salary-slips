package test;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.bag.SynchronizedSortedBag;

public class PascalTriangle {

	public static void main(String[] args) {
		List<Integer> row, prev = null;

		for (int i = 0; i <= 5; i++) {
			row = new ArrayList<Integer>();
			for (int j = 0; j <= i; j++) {

				if (j == 0 || j == i) {
					row.add(1);
				} else {
					
					row.add(prev.get(j - 1) + prev.get(j));
				}

			}
			
			prev=row;
			System.out.println(prev+"\n");
		}
		
	}

}

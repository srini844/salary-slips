package test;

import java.util.HashMap;

import org.testng.annotations.Test;

public class TestISO {
	
	public boolean isIsomorphic() {
		
		String str1 = "add";
		String str2 = "fao";
		
		if(str1.length()!=str2.length()) {
			return false;
		}
		HashMap<Character, Character> hashMap = new HashMap<>();
		for(int i=0;i<str1.length();i++) {
			char x = str1.charAt(i);
			char y = str2.charAt(i);
			
			if(hashMap.containsKey(x)) {
				
				if(hashMap.get(x)!=y) {
					return false;
				}
			}else
			if(hashMap.containsValue(y)) {
				return false;
			}
			hashMap.put(x, y);
			
		}
		
		
		
		
		
		return true;
	}
	
	public static void main(String[] args) {
		TestISO ts = new TestISO();
		System.out.println(ts.isIsomorphic());
	}

}

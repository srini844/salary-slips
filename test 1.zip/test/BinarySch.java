package test;

public class BinarySch {

	public static void main(String[] args) {
		int[] a = { 10, 24, 35, 42, 53, 90, 50, 86, 97, 100 };
		
		int key = 97;

		int min = 0, max = a.length - 1;
		
		while (min <= max) {
			int mid = (min + max) / 2;  
			System.out.println("Mid value is : "+mid);
			if (key == a[mid]) {
				System.out.println("Element is :" + key);
				break;
			} else if (key < a[mid]) {
				max = mid - 1;
			} else {
				min = mid + 1;
			}

		}
		if (min > max) {
			System.out.println("Searched number is not present");
		}

	}

}

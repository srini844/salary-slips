package test;

import org.testng.annotations.Test;

public class LoginPage {
	
	@Test(invocationCount = 2)
	public void  login() {
		
		System.out.println("Login page is launched");
		
		
	}
	
	
}

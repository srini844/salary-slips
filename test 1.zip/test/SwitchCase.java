package test;

public class SwitchCase {

	public static void main(String[] args) {
		
		String days ="Saturday";
		
		switch(days) {
		
				case "Saturday":
						System.out.println("It is Saturday");		
						break;
						
				case "Sunday":
						System.out.println("It is Sunday");
						break;
					
				case "Monday":
						System.out.println("It is Monday");
						break;
		
		}
		

	}

}

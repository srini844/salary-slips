package test;

import java.util.Arrays;
import java.util.Collections;

public class MedianSortedArrays {

	public static void main(String[] args) {

		int arr1[] = { 1,2};
		int arr2[] = {3,4};

		int c[] = new int[arr1.length + arr2.length];
		for (int i = 0; i < arr1.length; i++) {
			c[i] = arr1[i];
		}

		for (int i = 0; i < arr2.length; i++) {
			c[i+arr1.length] = arr2[i];
		}
		Arrays.sort(c);		
		System.out.println(Arrays.toString(c));
		if(c.length%2==0) {
			float x = (float) ((c[c.length/2]+c[c.length/2+1])/2.0);
			System.out.println("Value of x is : "+x);
		}
		else
		{
			float x = c[(int) (c.length/2.0)];
			System.out.println(x);
		}
	}

}

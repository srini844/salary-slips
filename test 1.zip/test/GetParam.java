package test;

import java.lang.reflect.Method;

public class GetParam {
	
	public static void method1(int x, int y, double z, String str) {
	}


	public static void main(String... args) throws NoSuchMethodException {
	
		Method mthd = GetParameterCount.class.getDeclaredMethod("method1", int.class,int.class,
				double.class,String.class);
		int parameterCount = mthd.getParameterCount();
		
		System.out.println(parameterCount);
	}

}

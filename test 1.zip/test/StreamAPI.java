package test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class StreamAPI {

	public static void main(String[] args) {
		ArrayList<Integer> values = new ArrayList<Integer>();
		for (int i = 1; i < 100; i++) {
			values.add(i);
		}

		List<Integer> collect = values.stream().filter(s -> s > 50).collect(Collectors.toList());
		System.out.println(collect);
		
		
		
	
	
		HashSet<String> set1  = new HashSet();
		
		set1.add("Test");
		set1.add("Test1");
		set1.add("Test2");
		set1.add("Test3");
		set1.add("Test4");		
		set1.add("Test5");
		
		System.out.println(set1.stream().filter(e-> e.equals("Test5")).findAny().get());
	
		System.out.println(set1.stream().anyMatch(e-> e.equals("Test5")));
	}
	
	
	
	
}



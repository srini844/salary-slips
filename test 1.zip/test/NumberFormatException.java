package test;

public class NumberFormatException {

	public static void main(String[] args) {
		
String s = "20,000.00";

System.out.println(s.replace(",", ""));
	}

}

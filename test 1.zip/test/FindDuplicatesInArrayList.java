package test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.stream.Collectors;
public class FindDuplicatesInArrayList {

	public static void main(String[] args) {
		ArrayList<String> arr = new ArrayList<String>();
		
			arr.add("Infosys");
			arr.add("TCS");
			arr.add("Tech-Mahindra");
			arr.add("Mphasis");
			arr.add("Mphasis");
			arr.add("HCL");
		
		HashSet<Object> hashSet = new HashSet();		
		System.out.println(arr.stream().distinct().collect(Collectors.toList()));
		
		
		for (String duplicates : arr) {

			if(hashSet.add(duplicates)==false) {
			System.out.println("Duplicates is : "+duplicates);
			System.out.println();
			}
			else
			{
				System.out.println("Without duplicates is : "+duplicates);	
			}
		}
		

	}

}

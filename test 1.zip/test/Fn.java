package test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Fn {
	
	
	@Test
	public void sampleTestCode() {
		
		System.setProperty("webdriver.chrome.silentOutput", "true");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");		
		
		WebElement ele = driver.findElement(By.id("Skills"));
		ele.click();
		
		List<WebElement> findElements = driver.findElements(By.xpath("//select[@id='Skills']/option"));
		System.out.println(findElements.size());
		
		WebElement collectts = findElements.stream().filter(m->m.getText().startsWith("C")).findFirst().orElse(null);
		System.out.println(collectts.getText());
		
		//List<WebElement> collectts = findElements.stream().filter(m->m.getText().contains("C")).collect(Collectors.toList());
		//collectts.forEach(System.out::println);
		
	long count = findElements.stream().filter(m->m.getText().contains("C")).count();
	
	System.out.println(count);
		
		
		
//		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
//		   LocalDateTime now = LocalDateTime.now();  
//		   System.out.println(dtf.format(now));
	}

}

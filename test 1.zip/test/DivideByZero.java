package test;

public class DivideByZero {
public static void main(String[] args) {
	
	try {
		int result = dividezero();
		System.out.println(result);
	}catch(ArithmeticException e) {
			e.printStackTrace();
		}
	finally	{
			System.out.println("Finally block executed");
		}
}

public static int dividezero() {
	
	int numerator = 10;
	int denominator = 0;
	return numerator/denominator;	
}

}

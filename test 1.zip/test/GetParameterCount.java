package test;

import java.lang.reflect.Method;

public class GetParameterCount {

	public static void method1(int x, String y, double z, String str) {
	}

	public static void main(String... args) throws NoSuchMethodException {
		Method mthd = GetParameterCount.class.getDeclaredMethod("method1", int.class, String.class, double.class,
				String.class);
		int paramCount = mthd.getParameterCount();
		System.out.println("No of parameters in method1 :  " + paramCount);
	}
}

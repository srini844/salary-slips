package test;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import com.graphbuilder.struc.LinkedList;

public class MethodsInArrayList {

	public static void main(String[] args) {

		HashMap<String, Integer> hmap = new HashMap();
		hmap.put("Shoe", 1200);
		hmap.put("Bag", 800);
		hmap.put("Pant", 700);

		/*
		 * hmap.computeIfPresent("Pant", (key, value) -> value + value * 10 / 100);
		 * System.out.println(hmap);
		 * 
		 * hmap.computeIfAbsent("shocks", key -> 100); System.out.println(hmap);
		 */
		
		hmap.forEach((key,value)-> {
			
			if(value>701) {
				System.out.println(key + "-> "+value);
			}
			
		});
		
		
		
		for(Entry<String, Integer> entry : hmap.entrySet()){
			if(entry.getValue()>=701) {
				System.out.println(entry.getKey());
			}
			
		}

	
		
		
		
		
		
		
		
		
		
	}
}

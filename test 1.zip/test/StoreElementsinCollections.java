package test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.apache.commons.collections4.bag.SynchronizedSortedBag;

public class StoreElementsinCollections {

	public static void main(String[] args) {
		HashMap<Integer, Object[]> hashMap = new HashMap<Integer, Object[]>();
		int key = 15;
		Object values[] = { "Steeve", "US", 30 };
		hashMap.put(key, values);

		
		Object[] storedObjects = hashMap.get(key);
		System.out.println(hashMap.get(key));
		
		
		 for (Object obj : storedObjects) {
			 System.out.println(obj);
			
		}
		 
					
		System.out.println(storedObjects[0]);
		System.out.println(storedObjects[1]);
		System.out.println(storedObjects[2]);   
		
	//*************************************************************************
		
		System.out.println("Enter the value to retrieve: ");
		Scanner s = new Scanner(System.in);
		int nextInt = s.nextInt();
		
		
		HashMap<Integer, List<String>> map = new HashMap<Integer, List<String>>();
		List<String> str = new ArrayList<String>();		
			str.add("Gold");
			str.add("US");
			str.add("35");		

		map.put(nextInt,str);
		
		System.out.println(map.get(nextInt)); 
		
		

		
		
		
		
	}

}

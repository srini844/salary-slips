package test;

public class Sample {
	
	public static void main(String[] args) {
		
		String st = "s";
		
		System.out.println(1 + 2 + st + 4 + 5);
	}

}

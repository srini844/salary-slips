package test;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		
		int originalNum,number=0,temp=0,remainder=0;
		boolean flag=false;
		System.out.println("Enter the number for computation : ");
		Scanner sc = new Scanner(System.in);
		number = sc.nextInt();
		
/******/int SizeOfNumber = (int) (Math.log10(number) + 1); 

		
		System.out.println(SizeOfNumber);
		originalNum = number;

		while(number!=0) {			
			remainder = number%10;			
			temp+= 	Math.pow(remainder, 3);
			number = number/10;
			System.out.println(temp);
		}
		
if(originalNum == temp) {
	System.out.println(originalNum + " is an armstrong number");
	}
else
{
	System.out.println(originalNum + " is not an armstrong number");
}
	}

}

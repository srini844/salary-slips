package test;

import java.util.HashMap;

public class Iso {
	
	
	public static boolean areIsomorphic(String str1,String str2) {
		
		
		if(str1.length()!=str2.length()) {
			return false;
		}
		HashMap<Character, Character> map = new HashMap<>();
		for (int i = 0; i < str1.length(); i++)   
		{  
		 
		char char_str1 = str1.charAt(i), char_str2 = str2.charAt(i);  
		  
		if (map.containsKey(char_str1))   
		{ 
			
			
		if (map.get(char_str1) != char_str2)  
		  
		return false;  
		}  
		else   
		{  
		     
		if (map.containsValue(char_str2)) {           
		return false; 
		
		}

		map.put(char_str1, char_str2); 
		System.out.println(map);
		}  
		}  
		return true;  
		}  
		
		
		

	
	public static void main(String[] args) {
			
		
		
		System.out.println(Iso.areIsomorphic("add", "fda"));
		
		
	}
	
}
		
		
		
		
	


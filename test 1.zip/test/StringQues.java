package test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class StringQues {

	public static void main(String[] args) {
		String str = "SILLYSPIERS";

		LinkedHashMap<Character, Integer> hashmap = new LinkedHashMap<Character, Integer>();
		char[] charArray = str.toCharArray();

		for (char c : charArray) {
			if (hashmap.containsKey(c)) {
				hashmap.put(c, hashmap.get(c) + 1);

			} else {
				hashmap.put(c, 1);
			}

		}
		int count=0;
		for (Entry<Character, Integer> entrySet : hashmap.entrySet()) {
			
			if(entrySet.getValue()==1) {
				count++;
				if(count==2) {
					System.out.println("Value of second element is : "+entrySet.getKey());
				}
				
			}
		}
	}

}

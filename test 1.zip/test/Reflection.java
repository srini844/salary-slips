package test;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Reflection {

	public static void main(String[] args) {

		TransactionPage trs = new TransactionPage();
		Class<? extends TransactionPage> cls = trs.getClass();

		Method[] methods = cls.getMethods();

		try {
			System.out.println(methods[0].invoke(trs));
		} catch ( IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e) {
			e.printStackTrace();
		}

		/*
		 * for (Method m : methods) { System.out.println(m.getName()); }
		 */

	}

}

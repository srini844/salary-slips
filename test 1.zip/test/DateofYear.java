package test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;

public class DateofYear {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Enter date :");
		int day = input.nextInt();
		
		System.out.println("Enter month :");
		int month = input.nextInt();
		
		System.out.println("Enter year :");
		int year = input.nextInt();
		
		input.close();
		
		
		
		
		LocalDate date = LocalDate.of(year, month, day);
		
		DayOfWeek dayOfWeek = date.getDayOfWeek();
		

		System.out.print(dayOfWeek);
	}

}

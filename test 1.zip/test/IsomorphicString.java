package test;

import java.util.HashMap;

import org.testng.annotations.Test;

public class IsomorphicString {


public static void main(String[] args) {
	

		HashMap<Character,Character> map1 = new HashMap<Character, Character>();
		HashMap<Character,Character> map2 = new HashMap<Character, Character>();
		
		String str1 = "add";
		String str2 = "foo";
		
		for(int i=0;i<str1.length();i++) {
			char new1 = str1.charAt(i);
			char new2 = str2.charAt(i);
			
			if(map1.containsKey(new1) && map1.get(new1) !=new2 || map2.containsKey(new2) && map2.get(new2)!=new1) {
				System.out.println("false"); }
			
			System.out.println(map1.put(new2, new1));
			}
			
		}
		

	}



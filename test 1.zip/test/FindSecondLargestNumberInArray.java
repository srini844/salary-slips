package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Random;import java.util.stream.Collector;
import java.util.stream.Collectors;

public class FindSecondLargestNumberInArray {
		public static void main(String[] args) {
	
			//Sorting Without using any inbuilt Method
			
					int []a = {10, 30, 25, 60, 45};			
			
			int j=1;
			int temp;
			
			while(j<a.length) {
				int i=0;
				while(i< (a.length)-j) {
					if(a[i] > a[i+1]) {
						temp = a[i];
						a[i] = a[i+1];
						a[i+1]=temp;				
					}i++;			
				}j++;
			} 
			
			
			
			
			  for(int k=0;k<a.length;k++) { System.out.println(a[k]); }
			    
			
			
			//Method 1: //Sorted in Descending
			List<Integer> nums = Arrays.asList(2, 17, 54, 14, 14, 33, 45, -11);			
			List<Integer> secondSmallest = nums.stream().sorted((x, y) -> Integer.compare(x, y)).collect(Collectors.toList());				     
				System.out.println("Second Largest Element (By skipping 1st element): "+secondSmallest.stream().skip(1).findFirst().orElse(null));


		// Method 2   //Sorted in Descending
				System.out.println("Descending Order (inBuilt Method)"+nums.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList()));
				
				// Method 3   //Sorted in Ascending
				System.out.println("Ascending Order:"+nums.stream().sorted().collect(Collectors.toList()));
					
				System.out.println(nums.stream().sorted().collect(Collectors.toList()));
				System.out.println(nums.stream().sorted().skip(1).findFirst().get());
		
		
		}
		
		
}

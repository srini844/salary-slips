package test;

public class ReplaceWithSpecialChar {

	public static void main(String[] args) {
		String s = "tomorrow";
		char[] charArray = s.toCharArray();

		String temp="";
		int x=0;
		for(int i=0;i<charArray.length;i++) {			
			if(charArray[i]=='o') {
				x+=1;
				if(x==2) {
					charArray[i]='$';
						}
				temp+=charArray[i];
			}
				else
					{
				temp+=charArray[i];
					}

		}
		System.out.println(temp);



	}

}

//System.out.println(charArray[i]);
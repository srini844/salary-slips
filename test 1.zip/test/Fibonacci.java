package test;

import java.io.InputStream;
import java.util.Scanner;

import org.apache.commons.collections4.bag.SynchronizedSortedBag;

public class Fibonacci {

	public static void main(String[] args) {
		int firstNum = 0, SecondNum = 1, NextNum = 0, range;

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range of fibonacci to be calculated : ");
		range = sc.nextInt();

		for (int i = 1; i <= range; i++) {
			System.out.print(firstNum + ",");
			NextNum = firstNum + SecondNum;
			firstNum = SecondNum;
			SecondNum = NextNum;
		}

	}

}

package test;

import org.testng.annotations.Test;

public class DashboardPage {
	
	@Test(dependsOnMethods = "test.LoginPage.login")
	public void dashboard() {		
		System.out.println("This is my dashboard method");
	}


}

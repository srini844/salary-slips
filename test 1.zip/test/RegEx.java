package test;

public class RegEx {

	public static void main(String[] args) {
		String str = "ATFC (2999)";
		
		//String newString = str.replaceAll("\\D", "");
		String newString = str.replaceAll("[^0-9]", "");
		
		System.out.println(newString);
		
		
		
		  Integer.parseInt(newString); if(Integer.parseInt(newString)>3000) {
		  System.out.println("Additional Wait"); } else {
		  System.out.println("No additional wait"); }
		 
		
	}
	
	
}

	


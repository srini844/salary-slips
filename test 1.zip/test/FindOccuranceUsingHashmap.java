package test;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FindOccuranceUsingHashmap {

	public static void main(String[] args) {
		String str = "Hello Mr Vaithi";
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		char[] charArray = str.toCharArray();
		for (char c : charArray) {

			if(c!=' ') {
				if (map.containsKey(c)) {

					map.put(c, map.get(c) + 1);
				} else {
					map.put(c, 1);
					//}

				}
			}
		}

			Set<Character> keySet = map.keySet();
			
	for (Character character : keySet) {
		if(map.get(character)>1) {
			System.out.println(character+ "=> is :"+ map.get(character));
		}

	}

			for(Map.Entry entrySet : map.entrySet()) {
				System.out.println(entrySet.getKey() +" occurances is " + entrySet.getValue());
			}
			
			



		

	}}

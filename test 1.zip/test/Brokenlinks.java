package test;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Brokenlinks {
	
	@Test	
	public void captureLinks() throws IOException {
	
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();		
		driver.manage().window().maximize();
		driver.navigate().to("https://sitebulb.com/hints/internal/query-string-contains-a-question-mark/");		
		List<WebElement> findElement = driver.findElements(By.tagName("a"));
		System.out.println("Total anchor tags available in the webpage:"+findElement.size());
		
			for (WebElement eachUrl : findElement) {
			System.err.println("URL IS : "+eachUrl.getAttribute("href"));
			URL url = new URL(eachUrl.getAttribute("href"));
			HttpURLConnection openConnection = (HttpURLConnection) url.openConnection();
			openConnection.setConnectTimeout(3000);
			openConnection.connect();
			
			if(openConnection.getResponseCode()==200)
			 System.out.println("Link is valid");
			else
				System.out.println("Link is broken");
			
		
			
		}
		
		
	}

}

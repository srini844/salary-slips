package test;

import java.util.Arrays;

public class BubbleSort {

	public static void main(String[] args) {

		int temp;
		int ele[] = { 50,40,30,20,10};
		
		//40,30,20,10,50

	

		 int j = 1;
		System.out.println("Length of array element :" + ele.length);
		while (j < ele.length) {
			int i = 0;
			while (i < ele.length - j) {
				if (ele[i] < ele[i + 1]) { 
					temp = ele[i];
					ele[i] = ele[i + 1];
					ele[i + 1] = temp;
				}
				i++;
			}
			j++;

		}
		for (int k = 0; k < ele.length; k++) {
			System.out.println(ele[k]);
		}
		
		
		

	}
}

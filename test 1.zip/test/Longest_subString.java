package test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Longest_subString {

	public static void main(String[] args) {
		lengthOfLongestSubString("pwwkew");

	}

	public static void lengthOfLongestSubString(String str) {
		String longestSubString = null;
		int longestSubStringLength = 0;

		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();

		char[] arr = str.toCharArray();

		
		for (int i = 0; i < arr.length; i++) {
			if (!map.containsKey(arr[i])) {
				map.put(arr[i], 1);
			} 
			if (map.size() > longestSubStringLength) {
				longestSubString = map.keySet().toString();
				longestSubStringLength = map.size();
			}

		}
		System.out.println(longestSubString);
		System.out.println(longestSubStringLength);
	}

}

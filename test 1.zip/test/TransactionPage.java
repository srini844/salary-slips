package test;

import org.testng.annotations.Test;

public class TransactionPage {
	
	//@Test(enabled = false)
	public void transaction() {
		System.out.println("This is my transaction method");
	}

}

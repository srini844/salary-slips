package stream;

import java.util.ArrayList;

public class Stream1 {

	public static void main(String[] args) {
		
		
	ArrayList<Integer> arList = new ArrayList<>();
	arList.add(10);
	arList.add(20);
	arList.add(30);
	arList.add(40);
	arList.add(50);
	arList.add(60);
	arList.add(70);
	arList.add(80);
	arList.add(90);
	arList.add(100);
	
	
	arList
		.stream()
		.filter(no-> no>50)
		.forEach(System.out::println);


	}

}

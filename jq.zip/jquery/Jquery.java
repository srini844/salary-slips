package jquery;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class Jquery {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
				ChromeDriver driver = new ChromeDriver(options);
					driver.navigate().to("https://jqueryui.com/tooltip/");
					//driver.manage().window().maximize();
					driver.manage().window().fullscreen();

		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()=' view source']")).click();
		System.out.println(driver.findElement(By.xpath("/html/body")).getCssValue("color"));
		System.out.println(driver.findElement(By.xpath("/html/body")).getCssValue("-webkit-text-size-adjust"));
		
		
	}

}
